// =====================================================================
// ClínicaRed Citas — Carga de la capa Gold en Power BI
// 1) Inicio > Transformar datos > Nuevo origen > Consulta en blanco.
//    Abra el Editor avanzado, pegue el bloque "fnCargarCsv" y nombre la consulta: fnCargarCsv
// 2) Administrar parámetros > Nuevo: RutaDatos (Texto) = carpeta donde descomprimió /data
//    p. ej.  C:\ClinicaRed\data
// 3) Por cada tabla, cree una consulta en blanco con UNA línea y nómbrela igual que el archivo:
//       = fnCargarCsv("fact_citas")
//    (lista de nombres al final de este archivo)
// Por qué: los CSV usan punto decimal; la cultura "en-US" evita que un Power BI en español
// convierta 5.3 mm en 53 mm.
// =====================================================================

// ---------- fnCargarCsv ----------
(nombre as text) as table =>
let
    Esquemas = [
        agg_condicion_cronica = {{"anio_mes", type text}, {"grupo_edad_id", Int64.Type}, {"periodo_politica", type text}, {"citas_debia_asistir", type number}, {"inasistencias", type number}, {"condicion_cronica", type text}, {"suprimido_k_anonimato", Int64.Type}},
        control_totales = {{"periodo", type text}, {"indicador", type text}, {"valor", type number}},
        dim_clima = {{"clima_key", type text}, {"sede_id", Int64.Type}, {"fecha_key", Int64.Type}, {"precipitacion_mm", type number}, {"temp_max_c", type number}, {"categoria_lluvia", type text}, {"categoria_lluvia_orden", Int64.Type}},
        dim_especialidad = {{"especialidad_id", Int64.Type}, {"especialidad", type text}, {"categoria", type text}, {"duracion_min", Int64.Type}, {"sobreagendable", Int64.Type}, {"cupos_por_hora", Int64.Type}},
        dim_fecha = {{"fecha_key", Int64.Type}, {"fecha", type date}, {"anio", Int64.Type}, {"mes_num", Int64.Type}, {"mes", type text}, {"anio_mes", type text}, {"mes_anio_orden", Int64.Type}, {"trimestre", type text}, {"dia_semana_num", Int64.Type}, {"dia_semana", type text}, {"es_festivo", Int64.Type}, {"nombre_festivo", type text}, {"es_dia_habil", Int64.Type}, {"periodo_politica", type text}},
        dim_franja = {{"franja_id", Int64.Type}, {"franja", type text}, {"bloque", type text}},
        dim_grupo_edad = {{"grupo_edad_id", Int64.Type}, {"grupo_edad", type text}, {"orden", Int64.Type}},
        dim_paciente = {{"paciente_sk", Int64.Type}, {"paciente_hash", type text}, {"sexo", type text}, {"es_menor_ref", Int64.Type}, {"canal_preferido", type text}},
        dim_profesional = {{"profesional_id", Int64.Type}, {"codigo_profesional", type text}, {"profesional", type text}, {"sede_id", Int64.Type}, {"especialidad_id", Int64.Type}},
        dim_rango_anticipacion = {{"rango_anticipacion_id", Int64.Type}, {"rango_anticipacion", type text}, {"orden", Int64.Type}},
        dim_riesgo = {{"riesgo_id", Int64.Type}, {"nivel_riesgo", type text}, {"orden", Int64.Type}, {"regla", type text}, {"politica_recordatorio", type text}},
        dim_sede = {{"sede_id", Int64.Type}, {"sede", type text}, {"ciudad", type text}, {"region", type text}},
        fact_agenda_bloque = {{"bloque_key", Int64.Type}, {"fecha_key", Int64.Type}, {"bloque", type text}, {"hora_inicio", Int64.Type}, {"horas_bloque", Int64.Type}, {"sede_id", Int64.Type}, {"especialidad_id", Int64.Type}, {"profesional_id", Int64.Type}, {"cupos_regulares", Int64.Type}, {"sobrecupos_habilitados", Int64.Type}, {"sobrecupos_usados", Int64.Type}, {"cupos_ofertados", Int64.Type}, {"citas_agendadas", Int64.Type}, {"citas_riesgo_alto", Int64.Type}, {"citas_atendidas", Int64.Type}, {"max_pacientes_esperando", Int64.Type}, {"sala_colapsada", Int64.Type}, {"periodo_politica", type text}},
        fact_calidad_datos = {{"fecha_key", Int64.Type}, {"fuente", type text}, {"tipo_defecto", type text}, {"registros", Int64.Type}, {"accion", type text}},
        fact_citas = {{"cita_id", Int64.Type}, {"origen", type text}, {"cita_origen_id", Int64.Type}, {"fecha_key", Int64.Type}, {"fecha_hora_cita", type datetime}, {"franja_id", Int64.Type}, {"bloque_key", Int64.Type}, {"sede_id", Int64.Type}, {"especialidad_id", Int64.Type}, {"profesional_id", Int64.Type}, {"paciente_sk", Int64.Type}, {"grupo_edad_id", Int64.Type}, {"es_menor", Int64.Type}, {"fecha_agendamiento", type datetime}, {"anticipacion_dias", Int64.Type}, {"rango_anticipacion_id", Int64.Type}, {"inasistencias_6m_previas", Int64.Type}, {"riesgo_id", Int64.Type}, {"primera_cita", Int64.Type}, {"agendamiento_restringido", Int64.Type}, {"periodo_politica", type text}, {"clima_key", type text}, {"recordatorios_programados", Int64.Type}, {"recordatorios_entregados", Int64.Type}, {"respuesta", type text}, {"estado_final", type text}, {"horas_cancelacion_antes", type number}, {"minutos_llegada", type number}, {"cupo_reasignado", Int64.Type}, {"minutos_oferta_lista_espera", type number}, {"es_inasistencia", Int64.Type}, {"es_atendida", Int64.Type}, {"es_cancelada_oportuna", Int64.Type}, {"debia_asistir", Int64.Type}, {"con_recordatorio_entregado", Int64.Type}, {"oferta_lista_espera_menor_10min", type number}},
        fact_mensajes = {{"mensaje_id", Int64.Type}, {"idempotency_key", type text}, {"cita_id", Int64.Type}, {"fecha_cita_key", Int64.Type}, {"tipo_recordatorio", type text}, {"canal", type text}, {"destinatario", type text}, {"riesgo_id", Int64.Type}, {"sede_id", Int64.Type}, {"especialidad_id", Int64.Type}, {"periodo_politica", type text}, {"fecha_hora_programada", type datetime}, {"fecha_hora_envio", type datetime}, {"fecha_envio_key", Int64.Type}, {"reprogramado_rn04", Int64.Type}, {"estado_final", type text}, {"respuesta", type text}, {"costo_cop", type number}}
    ],
    Ruta = Text.TrimEnd(RutaDatos, {"\", "/"}) & "\" & nombre & ".csv",
    Origen = Csv.Document(File.Contents(Ruta), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Encabezados = Table.PromoteHeaders(Origen, [PromoteAllScalars = true]),
    Esquema = Record.FieldOrDefault(Esquemas, nombre, {}),
    Tipado = Table.TransformColumnTypes(Encabezados, Esquema, "en-US")
in
    Tipado

// ---------- Consultas (una por tabla) ----------
// agg_condicion_cronica:  = fnCargarCsv("agg_condicion_cronica")
// control_totales:  = fnCargarCsv("control_totales")
// dim_clima:  = fnCargarCsv("dim_clima")
// dim_especialidad:  = fnCargarCsv("dim_especialidad")
// dim_fecha:  = fnCargarCsv("dim_fecha")
// dim_franja:  = fnCargarCsv("dim_franja")
// dim_grupo_edad:  = fnCargarCsv("dim_grupo_edad")
// dim_paciente:  = fnCargarCsv("dim_paciente")
// dim_profesional:  = fnCargarCsv("dim_profesional")
// dim_rango_anticipacion:  = fnCargarCsv("dim_rango_anticipacion")
// dim_riesgo:  = fnCargarCsv("dim_riesgo")
// dim_sede:  = fnCargarCsv("dim_sede")
// fact_agenda_bloque:  = fnCargarCsv("fact_agenda_bloque")
// fact_calidad_datos:  = fnCargarCsv("fact_calidad_datos")
// fact_citas:  = fnCargarCsv("fact_citas")
// fact_mensajes:  = fnCargarCsv("fact_mensajes")
