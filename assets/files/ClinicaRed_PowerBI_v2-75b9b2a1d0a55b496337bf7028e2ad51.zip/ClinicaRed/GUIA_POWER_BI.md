# ClínicaRed Citas — Guía del tablero Power BI (E-11)

## 0. Abrir el tablero ya armado (`ClinicaRed.pbip`)

1. Descomprima el zip en **`C:\`**: debe quedar `C:\ClinicaRed\ClinicaRed.pbip` y `C:\ClinicaRed\data\`.
   (Si usa otra carpeta: **Transformar datos > Editar parámetros > RutaDatos** con la ruta de `data`.)
2. Doble clic en `ClinicaRed.pbip` (Power BI Desktop actualizado). Si su versión no lo abre, active
   **Archivo > Opciones > Características en versión preliminar > Opción de guardado de proyectos de Power BI (.pbip)**
   y reinicie Power BI Desktop.
3. El proyecto trae el modelo, las relaciones, las 55 medidas y las 7 páginas, pero **sin datos cargados**.
   Clic en **Inicio > Actualizar** (≈ 1-2 min).
4. **Archivo > Guardar como > `.pbix`** si necesita entregar el archivo `.pbix` (E-11).
5. Verifique en la página *Resumen ejecutivo* que la tarjeta **Control CT-10** diga "✔ Cuadra con consulta de control".

Lo que sigue (secciones 2-5) explica cómo está construido, por si quiere modificarlo o rehacerlo a mano.
Dos ajustes rápidos que conviene hacer a mano porque dependen del gusto: formato condicional (escala de color)
en la matriz *Día de la semana × franja* y una línea de referencia en 15 % en el gráfico de sedes.

Kit para armar el `.pbix` que responde las 6 preguntas de negocio (sección 13 del caso) y cumple CT-10.

```
kit/
├── data/                      Capa Gold en CSV (12 meses: nov-2025 → oct-2026, escala 0,15)
├── scripts/generate_gold.py   Generador reproducible (semilla 42, idempotente, --scale)
├── powerbi/01_power_query.m   Función de carga con tipos y cultura en-US
├── powerbi/02_medidas.dax     55 medidas listas para la vista de consultas DAX
├── powerbi/03_tema_clinicared.json
└── sql/                       Extensiones mínimas al OLTP + vistas gold de control (probadas en PostgreSQL)
```

---

## 1. Qué contienen los datos

| Tabla | Grano | Filas | Uso |
|---|---|---|---|
| `fact_citas` | 1 cita (regular, sobrecupo o lista de espera) | 421.772 | Inasistencia, riesgo, recordatorios, lista de espera |
| `fact_agenda_bloque` | profesional × día × bloque (mañana/tarde) | 24.973 | Ocupación efectiva (RN-08), sobre-agenda y sala colapsada (RN-05) |
| `fact_mensajes` | 1 recordatorio (`idempotency_key` único) | 382.565 | Costos, entrega, RN-03/RN-04/RN-11 |
| `agg_condicion_cronica` | mes × grupo de edad × condición | 216 | RN-09: solo agregado, celdas con < 10 pacientes suprimidas |
| `fact_calidad_datos` | día × fuente × defecto | 1.885 | Página de calidad / observabilidad |
| `control_totales` | periodo × indicador | 15 | Cuadre CT-10 calculado fuera de Power BI |
| `dim_*` | fecha, sede (22), especialidad (17, catálogo F7), profesional, paciente (seudonimizado), franja (hora), riesgo, grupo de edad, rango de anticipación, clima (sede × día) | — | Ejes de análisis |

**Periodo de política**: `PRE` (nov-2025 a abr-2026: SMS a todos a las 24 h, sobre-agenda manual, lista de espera manual) y `POST` (may-2026 en adelante: RN-02 a RN-07 activas). Así el tablero muestra el antes/después que pide E-16.

**Privacidad (RN-09, RNF-01)**: `dim_paciente` no tiene nombre, documento ni condiciones clínicas; solo `paciente_hash`, sexo y canal. Las condiciones crónicas existen únicamente en `agg_condicion_cronica`, por eso CA-08 se cumple por diseño.

---

## 2. Carga (Power Query)

1. **Archivo > Opciones > Carga de datos (archivo actual)**: desmarcar *Detectar automáticamente nuevas relaciones*. Si no, Power BI une `dim_profesional` con `dim_sede` y aparecen caminos ambiguos.
2. **Transformar datos > Administrar parámetros > Nuevo**: `RutaDatos`, tipo Texto, valor = carpeta `data` (ej. `C:\ClinicaRed\data`).
3. **Nuevo origen > Consulta en blanco > Editor avanzado**: pegar todo `01_power_query.m`. Nombre de la consulta: `fnCargarCsv`.
4. Crear 16 consultas en blanco, cada una con una línea y el mismo nombre del archivo, ej.:
   `= fnCargarCsv("fact_citas")`
5. **Cerrar y aplicar.**

> ¿Por qué no usar el conector CSV directo? Con Power BI en español el paso automático "Tipo cambiado" convierte `5.3` en `53`. La función fija la cultura `en-US`.

---

## 3. Modelo (relaciones)

Todas **de varios a uno, dirección única**, de la tabla de hechos hacia la dimensión:

| Desde | Columna | Hacia |
|---|---|---|
| fact_citas | fecha_key | dim_fecha |
| fact_citas | sede_id / especialidad_id / profesional_id | dim_sede / dim_especialidad / dim_profesional |
| fact_citas | paciente_sk | dim_paciente |
| fact_citas | franja_id | dim_franja |
| fact_citas | riesgo_id | dim_riesgo |
| fact_citas | grupo_edad_id | dim_grupo_edad |
| fact_citas | rango_anticipacion_id | dim_rango_anticipacion |
| fact_citas | clima_key | dim_clima |
| fact_agenda_bloque | fecha_key / sede_id / especialidad_id / profesional_id | dim_fecha / dim_sede / dim_especialidad / dim_profesional |
| fact_mensajes | **fecha_cita_key** | dim_fecha |
| fact_mensajes | sede_id / especialidad_id / riesgo_id | dim_sede / dim_especialidad / dim_riesgo |
| fact_calidad_datos | fecha_key | dim_fecha |
| agg_condicion_cronica | grupo_edad_id | dim_grupo_edad |

`control_totales` queda sin relaciones. `dim_profesional[sede_id]` y `[especialidad_id]` **no** se relacionan (los hechos ya llevan esas claves).

**Ordenar por columna**: `dim_fecha[mes]` por `mes_num`; `dim_fecha[dia_semana]` por `dia_semana_num`; `dim_riesgo[nivel_riesgo]` por `orden`; `dim_grupo_edad[grupo_edad]` por `orden`; `dim_rango_anticipacion[rango_anticipacion]` por `orden`; `dim_clima[categoria_lluvia]` por `categoria_lluvia_orden`.

**Ocultar** en la vista de informe todas las columnas `*_id`, `*_key` y `paciente_hash`.

Marcar `dim_fecha` como tabla de fechas (columna `fecha`).

---

## 4. Medidas

Vista de consultas DAX → pegar `02_medidas.dax` → **Actualizar modelo con cambios**. Ejecute el `EVALUATE` del final: debe dar PRE 21,4 % y POST 20,3 % de inasistencia, igual que `control_totales.csv`.

Formatos: porcentaje (1 decimal) para tasas, ocupación y variaciones; moneda COP sin decimales para costos; las medidas "(pp)" en porcentaje.

---

## 5. Páginas y visuales

Tema: **Vista > Temas > Buscar temas** → `03_tema_clinicared.json`. Segmentadores comunes en todas las páginas (sincronizados): `dim_fecha[anio_mes]`, `dim_sede[region]`, `dim_sede[sede]`, `dim_especialidad[categoria]`.

### P1 · Resumen ejecutivo (objetivos de la sección 3)
- 4 tarjetas KPI con objetivo: **Tasa inasistencia** vs `Meta inasistencia` (15 %); **Variación costo mensual POST vs PRE** vs `Meta reducción costo` (−30 %); **Ocupación especialistas** vs `Meta ocupación especialistas` (90 %); **% ofertas a lista de espera < 10 min**.
- Gráfico de líneas: `dim_fecha[anio_mes]` × `Tasa inasistencia` + línea constante `Meta inasistencia`. Agregar una línea vertical/anotación en 2026-05 ("inicio política").
- Columnas agrupadas: `dim_riesgo[nivel_riesgo]` × `Tasa inasistencia`, leyenda `dim_fecha[periodo_politica]`.
- Tarjeta `control_totales[Cuadre CT-10]` en la esquina (evidencia de CT-10 en la demo).

### P2 · Inasistencia (pregunta 1)
- Barras horizontales: `dim_sede[sede]` × `Tasa inasistencia` (ordenado desc.), línea de referencia 15 %.
- Barras: `dim_especialidad[especialidad]` × `Tasa inasistencia` con formato condicional (rojo > 30 %).
- **Matriz mapa de calor**: filas `dim_fecha[dia_semana]`, columnas `dim_franja[franja]`, valor `Tasa inasistencia`, formato condicional de fondo (escala verde→rojo).
- Columnas: `dim_grupo_edad[grupo_edad]` × `Tasa inasistencia`.
- Tabla de detalle de estados: `fact_citas[estado_final]` × `Citas programadas`.

### P3 · Ocupación efectiva (pregunta 2)
- Medidor: `Ocupación especialistas`, destino `Meta ocupación especialistas`.
- Matriz: filas `dim_sede[sede]` → `dim_profesional[profesional]` (jerarquía), valores `Cupos ofertados`, `Atendidas en agenda`, `Ocupación efectiva` (barras de datos).
- Columnas: `dim_especialidad[categoria]` × `Ocupación efectiva`, leyenda `periodo_politica`.
- Línea: `anio_mes` × `Ocupación efectiva` por `categoria`.

### P4 · Recordatorios y costos (preguntas 3 y 4)
- Columnas agrupadas: `dim_riesgo[nivel_riesgo]` × `Tasa inasistencia con recordatorio` y `Tasa inasistencia sin recordatorio` (filtro de página `periodo_politica = POST` con opción de cambiar).
- Tarjetas: `Mensajes enviados`, `Costo mensajes`, `Inasistencias evitadas (estimado)`, `Costo por inasistencia evitada`.
- Columnas apiladas: `anio_mes` × `Costo mensajes`, leyenda `fact_mensajes[canal]`.
- Tabla: `periodo_politica` con `Mensajes por cita`, `Costo unitario promedio`, `Costo mensual promedio` → separa el ahorro por **volumen** (focalización por riesgo) del ahorro por **canal** (WhatsApp más barato).
- Embudo: `fact_mensajes[estado_final]` (enviado → entregado → leído → respondido). Tarjetas pequeñas: `Mensajes reprogramados RN-04`, `Mensajes omitidos por ventana`.

### P5 · Sobre-agenda y sala de espera (pregunta 5)
- Tarjetas: `Sobrecupos usados`, `Bloques con sala colapsada`, `% colapso con sobrecupo` vs `% colapso sin sobrecupo`.
- Columnas: `periodo_politica` × `Sobrecupos usados` y `Bloques con sala colapsada` (manual vs regla RN-05).
- Barras: `dim_especialidad[especialidad]` × `Sobrecupos usados`, con `dim_especialidad[sobreagendable]` en información sobre herramientas; con filtro POST debe dar **0** en especialidades no sobre-agendables (evidencia CA-06).

### P6 · Factores: clima y anticipación (pregunta 6)
- Columnas: `dim_clima[categoria_lluvia]` × `Tasa inasistencia`.
- Columnas: `dim_rango_anticipacion[rango_anticipacion]` × `Tasa inasistencia`.
- Dispersión: eje X `dim_clima[precipitacion_mm]` (no resumir → agrupar por `dim_clima[clima_key]` como detalle), eje Y `Tasa inasistencia`, tamaño `Citas programadas`.
- Matriz agregada RN-09: `agg_condicion_cronica[condicion_cronica]` × `dim_grupo_edad[grupo_edad]`, valor `Tasa inasistencia condición crónica` (las celdas suprimidas aparecen vacías: así se demuestra CA-08).

### P7 (opcional) · Calidad de datos y operación
- Columnas apiladas: `anio_mes` × `Registros con defecto`, leyenda `fact_calidad_datos[tipo_defecto]`; tabla por `accion` (cuarentena, corregido, descartado).

---

## 6. Lo que mostrará el tablero con estos datos

| Indicador | PRE | POST | Meta | Lectura |
|---|---|---|---|---|
| Tasa de inasistencia | 21,4 % | 20,3 % | < 15 % | No se alcanza |
| Inasistencia riesgo Alto | 40,3 % | 24,5 % | — | La doble alerta + RN-07 funciona en Alto |
| Inasistencia riesgo Bajo | 12,4 % | 17,6 % | — | Quitar el recordatorio a Bajo sube su inasistencia |
| Costo mensual de mensajes | 1,35 M COP | 0,93 M COP | −30 % | −30,7 %: se cumple |
| Ocupación especialistas | 62,9 % | 68,5 % | 90 % | Mejora, pero lejos de la meta |
| Ofertas a lista de espera < 10 min | — | 99,3 % | 100 % (CA-07) | El 0,7 % restante va al runbook |
| Bloques con sala colapsada: con sobrecupo vs sin él | 3,0 % vs 1,5 % (todo el año) | | — | El sobrecupo duplica el riesgo de colapso |
| Inasistencia con anticipación > 30 días | 40,7 % (todo el año) | | — | Muy por encima de 0-2 días (18,4 %) |

**Mensaje para la presentación**: la política por reglas cumple el ahorro, pero no la meta de inasistencia. Ese es un buen hallazgo para E-16 y para un ADR, por ejemplo: mantener un recordatorio barato (WhatsApp) para Bajo, o bajar a 30 días el umbral de anticipación de RN-02.

⚠️ **Estas cifras salen de la simulación**. Los efectos (cuánto reduce un recordatorio, tasas de entrega, costos SMS 40 COP / WhatsApp 25 COP) son supuestos declarados en `ASSUMPTIONS` dentro de `generate_gold.py`. Sirven para construir y probar el tablero, no como resultado del negocio. Las cifras reales salen cuando el tablero lea su pipeline.

---

## 7. Hallazgos sobre las reglas (para los ADR)

1. **RN-04 + CA-04 ("siguiente día hábil")**: un recordatorio de 24 h para una cita del lunes cae en domingo y se corre al lunes 07:00, casi encima de la cita. Con la regla literal se omitieron 4.029 mensajes (y se reprogramaron 39.479). El equipo debe decidir si adelanta al último horario válido anterior.
2. **RN-02 por conteo absoluto**: los pacientes que más usan el servicio (crónicos) acumulan 2 inasistencias aunque su tasa sea baja, y sube la proporción de riesgo Alto (≈ 25 %). Conviene evaluar una tasa en vez de un conteo.
3. **RN-05 "franja"**: si la franja es de una hora, con 2-3 cupos/hora casi nunca hay 3 citas Alto y la regla no actúa. Aquí se interpretó como **bloque de agenda** (mañana/tarde). Documéntelo en un ADR.
4. **RN-08 denominador**: `cupos ofertados = regulares + sobrecupos habilitados`. Es conservador y evita ocupaciones > 100 %.
5. **Tasa de inasistencia**: denominador = citas que debían asistir (excluye cancelaciones ≥ 4 h, CA-02).

---

## 8. Pasar de CSV a la fuente real

- **Local / control**: ejecutar `sql/01_extensiones_oltp.sql` y `sql/02_vistas_gold.sql` sobre `clinicared_db`. Las vistas ya aplican RN-01, RN-02, RN-07, RN-08 y seudonimización. Se probaron con el `01_init_schema.sql` del repositorio: CA-01, CA-02 y CA-03 dan el resultado esperado.
- **AWS (demo CT-07)**: Spark escribe las mismas tablas en `s3://…/gold/` (Parquet, particionado por `anio_mes`), Glue Catalog las expone y Power BI se conecta con el **conector Amazon Athena** (ODBC; puerta de enlace si se publica en el servicio). Si se mantienen los mismos nombres de tablas y columnas, solo cambia el origen en Power Query; las medidas y los visuales quedan iguales.
- **Seed del backend**: hoy `generate_seed.py` crea 2 sedes, 4 especialidades y 100 citas futuras sin asistencias ni mensajes. Para alimentar el tablero con la fuente real debe generar `booked_at`, `cancelled_at`, `attendances`, `messages` y `schedule_blocks`. La lógica de `generate_gold.py` (funciones `nueva_cita`, `emitir_mensajes`, `resolver`) se puede llevar al seed.

Regenerar los datos: `python scripts/generate_gold.py --out data --scale 0.15` (`--scale 1.0` ≈ 2,8 M citas, volumen real).
