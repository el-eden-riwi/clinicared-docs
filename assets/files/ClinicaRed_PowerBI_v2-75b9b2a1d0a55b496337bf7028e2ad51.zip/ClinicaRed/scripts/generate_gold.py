"""
ClínicaRed Citas — Generador de la capa GOLD (modelo estrella) para Power BI.

Simula 12 meses de operación de la red (22 sedes) aplicando las reglas de negocio
RN-01..RN-11 del caso, y escribe dimensiones y hechos en CSV (UTF-8, separador ',',
decimal '.', fechas ISO) listos para Power BI.

- Semilla fija (reproducible) e idempotente: borra y reescribe la carpeta de salida.
- Volumen parametrizable con --scale (1.0 = volumen real: ~9.000 citas/día, 640 profesionales).
- Política de recordatorios por riesgo activa desde --policy-start (antes: SMS a todos a las 24 h,
  sobre-agenda manual, lista de espera manual). Permite comparar PRE vs POST en el tablero.

IMPORTANTE: los efectos (cuánto reduce la inasistencia un recordatorio, etc.) son SUPUESTOS de
simulación definidos en ASSUMPTIONS, no hallazgos. En producción estas tablas se alimentan desde
Silver (PostgreSQL F2 + admisiones F3 + webhooks F4 + Open-Meteo F6 + Nager.Date F5).

Uso:
    python generate_gold.py --out ../data --scale 0.15
"""
import argparse
import hashlib
import math
import shutil
from collections import defaultdict, deque
from datetime import date, datetime, timedelta
from pathlib import Path

import holidays
import numpy as np
import pandas as pd
from faker import Faker

# --------------------------------------------------------------------------------------
# Supuestos (documentados; ajustables)
# --------------------------------------------------------------------------------------
ASSUMPTIONS = {
    "costo_sms_cop": 40.0,
    "costo_whatsapp_cop": 25.0,
    "share_whatsapp": 0.55,
    "p_entrega": 0.93,             # mensaje entregado
    "p_leido_si_entregado": 0.72,
    "p_respuesta_si_leido": 0.45,
    "or_1_recordatorio": 0.72,     # odds ratio de inasistencia con 1 recordatorio entregado
    "or_2_recordatorios": 0.45,    # con 2 recordatorios entregados
    "or_confirmado_restringido": 0.50,
    "p_confirma_restringido": 0.62,
    "p_cancela_si_intencion_y_lee": 0.35,
    "p_cancela_telefono_si_intencion": 0.22,
    "p_reasigna_pre": {"ge24": 0.35, "4a24": 0.10},
    "p_reasigna_post": {"ge24": 0.80, "4a24": 0.55},
    "p_franja_sobreagenda_manual_pre": 0.30,
    "umbral_sala_colapsada": 3,
    "k_anonimato": 10,
}

SEDES = [
    ("Sede Norte Barranquilla", "Barranquilla", "Caribe"), ("Sede Centro Barranquilla", "Barranquilla", "Caribe"),
    ("Sede Riomar Barranquilla", "Barranquilla", "Caribe"), ("Sede Viva Malambo", "Malambo", "Caribe"),
    ("Sede Soledad", "Soledad", "Caribe"), ("Sede Bocagrande Cartagena", "Cartagena", "Caribe"),
    ("Sede Manga Cartagena", "Cartagena", "Caribe"), ("Sede Santa Marta", "Santa Marta", "Caribe"),
    ("Sede Montería", "Montería", "Caribe"), ("Sede Valledupar", "Valledupar", "Caribe"),
    ("Sede Sincelejo", "Sincelejo", "Caribe"), ("Sede Chapinero Bogotá", "Bogotá", "Andina"),
    ("Sede Usaquén Bogotá", "Bogotá", "Andina"), ("Sede Kennedy Bogotá", "Bogotá", "Andina"),
    ("Sede Suba Bogotá", "Bogotá", "Andina"), ("Sede Poblado Medellín", "Medellín", "Andina"),
    ("Sede Laureles Medellín", "Medellín", "Andina"), ("Sede Bello", "Medellín", "Andina"),
    ("Sede Norte Cali", "Cali", "Pacífico"), ("Sede Sur Cali", "Cali", "Pacífico"),
    ("Sede Bucaramanga", "Bucaramanga", "Andina"), ("Sede Pereira", "Pereira", "Andina"),
]
TEMP_CIUDAD = {"Barranquilla": 32, "Malambo": 33, "Soledad": 33, "Cartagena": 31, "Santa Marta": 32,
               "Montería": 32, "Valledupar": 34, "Sincelejo": 32, "Bogotá": 19, "Medellín": 27,
               "Cali": 29, "Bucaramanga": 27, "Pereira": 26}

# F7 catálogo: nombre, categoría, duración (min), sobre-agendable, peso demanda, anticipación media (días), ajuste logit no-show
ESPECIALIDADES = [
    ("Medicina General", "Medicina general", 20, True, 10, 4, -0.10),
    ("Pediatría", "Especialista", 20, True, 3, 9, 0.05),
    ("Ginecología", "Especialista", 20, True, 2, 16, 0.10),
    ("Medicina Interna", "Especialista", 30, True, 2, 18, 0.05),
    ("Cardiología", "Especialista", 30, True, 2, 22, -0.05),
    ("Dermatología", "Especialista", 20, True, 2, 24, 0.55),
    ("Ortopedia", "Especialista", 20, True, 2, 20, 0.20),
    ("Oftalmología", "Especialista", 20, True, 2, 21, 0.25),
    ("Neurología", "Especialista", 30, True, 1, 26, 0.15),
    ("Endocrinología", "Especialista", 30, True, 1, 25, 0.10),
    ("Psiquiatría", "Especialista", 40, False, 1, 20, 0.75),
    ("Psicología", "Especialista", 40, False, 2, 12, 0.70),
    ("Oncología", "Especialista", 30, False, 1, 10, -0.60),
    ("Laboratorio Clínico", "Laboratorio", 10, True, 5, 2, -0.35),
    ("Ecografía", "Imágenes diagnósticas", 20, True, 2, 8, 0.00),
    ("Rayos X", "Imágenes diagnósticas", 15, True, 2, 3, -0.20),
    ("Resonancia Magnética", "Imágenes diagnósticas", 40, False, 1, 14, 0.10),
]

GRUPOS_EDAD = [(1, "0-17", 0, 17), (2, "18-29", 18, 29), (3, "30-44", 30, 44),
               (4, "45-59", 45, 59), (5, "60-74", 60, 74), (6, "75+", 75, 200)]
AJ_EDAD = {1: 0.05, 2: 0.40, 3: 0.15, 4: -0.05, 5: -0.25, 6: -0.10}
AJ_DOW = {0: 0.18, 1: 0.0, 2: -0.05, 3: 0.0, 4: 0.12, 5: 0.25}
RANGOS_ANTIC = [(1, "0-2 días", 0, 2), (2, "3-7 días", 3, 7), (3, "8-10 días", 8, 10),
                (4, "11-20 días", 11, 20), (5, "21-30 días", 21, 30), (6, "> 30 días", 31, 10_000)]
CONDICIONES = [("Hipertensión", 0.20), ("Diabetes", 0.10), ("EPOC/Asma", 0.06)]


def grupo_edad(edad):
    for gid, _, lo, hi in GRUPOS_EDAD:
        if lo <= edad <= hi:
            return gid
    return 6


def rango_antic(d):
    for rid, _, lo, hi in RANGOS_ANTIC:
        if lo <= d <= hi:
            return rid
    return 6


def logistic(x):
    return 1.0 / (1.0 + math.exp(-x))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="../data")
    ap.add_argument("--scale", type=float, default=0.15)
    ap.add_argument("--start", default="2025-11-01")
    ap.add_argument("--end", default="2026-10-31")
    ap.add_argument("--policy-start", default="2026-05-01")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--base-logit", type=float, default=-0.93)
    args = ap.parse_args()

    A = ASSUMPTIONS
    rng = np.random.default_rng(args.seed)
    fake = Faker("es_CO")
    Faker.seed(args.seed)
    out = Path(args.out)
    if out.exists():
        shutil.rmtree(out)  # idempotencia: reescritura completa
    out.mkdir(parents=True)

    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    policy_start = date.fromisoformat(args.policy_start)
    fest = holidays.CO(years=range(start.year - 1, end.year + 2))
    days = [start + timedelta(i) for i in range((end - start).days + 1)]
    warm = start - timedelta(days=182)  # calentamiento: genera historial de inasistencias (no se exporta)
    sim_days = [warm + timedelta(i) for i in range((end - warm).days + 1)]

    def es_habil(d):
        return d.weekday() != 6 and d not in fest

    # ---------------- dim_fecha ----------------
    meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
             "septiembre", "octubre", "noviembre", "diciembre"]
    dias_n = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
    dim_fecha = pd.DataFrame([{
        "fecha_key": int(d.strftime("%Y%m%d")), "fecha": d.isoformat(), "anio": d.year,
        "mes_num": d.month, "mes": meses[d.month - 1], "anio_mes": f"{d.year}-{d.month:02d}",
        "mes_anio_orden": d.year * 100 + d.month, "trimestre": f"T{(d.month - 1) // 3 + 1}",
        "dia_semana_num": d.weekday() + 1, "dia_semana": dias_n[d.weekday()],
        "es_festivo": int(d in fest), "nombre_festivo": fest.get(d, ""),
        "es_dia_habil": int(es_habil(d)),
        "periodo_politica": "POST" if d >= policy_start else "PRE",
    } for d in days])

    # ---------------- dims catálogo ----------------
    dim_sede = pd.DataFrame([{"sede_id": i + 1, "sede": n, "ciudad": c, "region": r}
                             for i, (n, c, r) in enumerate(SEDES)])
    dim_esp = pd.DataFrame([{
        "especialidad_id": i + 1, "especialidad": e[0], "categoria": e[1], "duracion_min": e[2],
        "sobreagendable": int(e[3]), "cupos_por_hora": max(1, 60 // e[2]),
    } for i, e in enumerate(ESPECIALIDADES)])
    dim_franja = pd.DataFrame([{"franja_id": h, "franja": f"{h:02d}:00-{h + 1:02d}:00",
                                "bloque": "Mañana" if h < 12 else "Tarde"} for h in range(7, 19)])
    dim_riesgo = pd.DataFrame([
        {"riesgo_id": 1, "nivel_riesgo": "Alto", "orden": 1,
         "regla": ">=2 inasistencias en 6 meses o anticipación >20 días sin confirmar",
         "politica_recordatorio": "72 h y 24 h"},
        {"riesgo_id": 2, "nivel_riesgo": "Medio", "orden": 2,
         "regla": "1 inasistencia en 6 meses o anticipación >10 días", "politica_recordatorio": "24 h"},
        {"riesgo_id": 3, "nivel_riesgo": "Bajo", "orden": 3, "regla": "Otro caso",
         "politica_recordatorio": "Ninguno (salvo primera cita: 24 h)"},
    ])
    dim_grupo_edad = pd.DataFrame([{"grupo_edad_id": g, "grupo_edad": l, "orden": g} for g, l, _, _ in GRUPOS_EDAD])
    dim_rango = pd.DataFrame([{"rango_anticipacion_id": r, "rango_anticipacion": l, "orden": r}
                              for r, l, _, _ in RANGOS_ANTIC])

    # ---------------- clima (simulado; prod = Open-Meteo F6) ----------------
    clima_rows = []
    for _, s in dim_sede.iterrows():
        for d in sim_days:
            m = d.month
            if s.region == "Caribe":
                p_rain = 0.08 if m in (12, 1, 2, 3) else (0.55 if m in (9, 10, 11) else 0.35)
            else:
                p_rain = 0.6 if m in (4, 5, 10, 11) else 0.35
            mm = float(rng.gamma(1.3, 11.0)) if rng.random() < p_rain else float(rng.uniform(0, 0.8))
            mm = round(mm, 1)
            cat = "Seco (<1 mm)" if mm < 1 else "Leve (1-10 mm)" if mm < 10 else \
                "Moderada (10-30 mm)" if mm < 30 else "Fuerte (>30 mm)"
            cat_ord = 1 if mm < 1 else 2 if mm < 10 else 3 if mm < 30 else 4
            clima_rows.append({
                "clima_key": f"{s.sede_id:02d}-{d.strftime('%Y%m%d')}", "sede_id": s.sede_id,
                "fecha_key": int(d.strftime("%Y%m%d")), "precipitacion_mm": mm,
                "temp_max_c": round(TEMP_CIUDAD[s.ciudad] + rng.normal(0, 1.6) - mm * 0.04, 1),
                "categoria_lluvia": cat, "categoria_lluvia_orden": cat_ord})
    dim_clima = pd.DataFrame(clima_rows)
    precip = {(r.sede_id, r.fecha_key): r.precipitacion_mm for r in dim_clima.itertuples()}
    dim_clima = dim_clima[dim_clima.fecha_key >= int(start.strftime("%Y%m%d"))].reset_index(drop=True)

    # ---------------- profesionales ----------------
    n_prof = max(len(SEDES) * 2 + 5, round(640 * args.scale))
    weights = np.array([e[4] for e in ESPECIALIDADES], float)
    weights /= weights.sum()
    prof = []
    for sid in range(1, len(SEDES) + 1):  # cada sede: 1 MG + 1 Laboratorio
        prof += [(sid, 1), (sid, 14)]
    for _ in range(n_prof - len(prof)):
        prof.append((int(rng.integers(1, len(SEDES) + 1)), int(rng.choice(len(ESPECIALIDADES), p=weights)) + 1))
    dim_prof = pd.DataFrame([{
        "profesional_id": i + 1, "codigo_profesional": f"PRO-{i + 1:04d}",
        "profesional": f"{fake.first_name()} {fake.last_name()}", "sede_id": s, "especialidad_id": e,
    } for i, (s, e) in enumerate(prof)])

    # ---------------- pacientes (seudonimizados) ----------------
    n_pac = round(400_000 * args.scale)
    ref = start
    is_minor = rng.random(n_pac) < 0.22
    edad = np.where(is_minor, rng.integers(0, 18, n_pac),
                    np.clip(rng.gamma(4.5, 10.0, n_pac) + 12, 18, 95).astype(int))
    sexo = np.where(rng.random(n_pac) < 0.56, "F", "M")
    activity = rng.gamma(2.5, 1.0, n_pac)
    propension = rng.normal(0, 1.15, n_pac)
    canal_pref = np.where(rng.random(n_pac) < A["share_whatsapp"], "WhatsApp", "SMS")
    fnac = [ref - timedelta(days=int(e * 365.25 + rng.integers(0, 365))) for e in edad]
    cond = {c: (rng.random(n_pac) < p * np.where(edad >= 40, 1.6, 0.4)) for c, p in CONDICIONES}
    pac_hash = [hashlib.sha256(f"CR|{1_000_000_000 + i * 7919}".encode()).hexdigest()[:16] for i in range(n_pac)]
    dim_pac = pd.DataFrame({
        "paciente_sk": np.arange(1, n_pac + 1), "paciente_hash": pac_hash, "sexo": sexo,
        "es_menor_ref": is_minor.astype(int), "canal_preferido": canal_pref,
    })
    minors_idx = np.where(is_minor)[0]
    adults_idx = np.where(~is_minor)[0]
    p_min = activity[minors_idx] / activity[minors_idx].sum()
    p_adu = activity[adults_idx] / activity[adults_idx].sum()

    def draw_patient(esp_id):
        if esp_id == 2 or (esp_id in (1, 14, 15, 16) and rng.random() < 0.10):
            return int(rng.choice(minors_idx, p=p_min))
        return int(rng.choice(adults_idx, p=p_adu))

    # pre-sorteo masivo para velocidad
    pool_min = list(rng.choice(minors_idx, size=400_000, p=p_min))
    pool_adu = list(rng.choice(adults_idx, size=3_000_000, p=p_adu))

    def fast_patient(esp_id):
        if esp_id == 2 or (esp_id in (1, 14, 15, 16) and rng.random() < 0.10):
            return int(pool_min.pop()) if pool_min else draw_patient(esp_id)
        return int(pool_adu.pop()) if pool_adu else draw_patient(esp_id)

    def edad_en(pi, d):
        f = fnac[pi]
        return d.year - f.year - ((d.month, d.day) < (f.month, f.day))

    # ---------------- agenda (franjas) y citas regulares ----------------
    esp_info = {i + 1: e for i, e in enumerate(ESPECIALIDADES)}
    franjas = []  # dicts
    for p in dim_prof.itertuples():
        e = esp_info[p.especialidad_id]
        cph = max(1, 60 // e[2])
        for d in sim_days:
            if not es_habil(d):
                continue
            if d.weekday() == 5 and p.especialidad_id not in (1, 2, 14):
                continue
            if rng.random() < 0.06:  # ausencias / vacaciones del profesional
                continue
            block = [7, 8, 9, 10] if (d.weekday() == 5 or rng.random() < 0.55) else [13, 14, 15, 16]
            if p.especialidad_id in (1, 14) and d.weekday() != 5 and rng.random() < 0.5:
                block = block + ([11, 12] if block[0] == 7 else [17, 18])
            # RN-05: "franja" = bloque de agenda del profesional (mañana/tarde); la hora se analiza aparte
            franjas.append({"profesional_id": p.profesional_id, "sede_id": p.sede_id,
                            "especialidad_id": p.especialidad_id, "fecha": d, "horas": block,
                            "bloque": "Mañana" if block[0] < 12 else "Tarde", "cph": cph,
                            "cupos_regulares": cph * len(block)})
    print(f"bloques de agenda: {len(franjas):,}")

    # citas por día
    citas = []        # lista de dicts finales
    fr_by_day = defaultdict(list)
    for fi, f in enumerate(franjas):
        f["franja_idx"] = fi
        fr_by_day[f["fecha"]].append(fi)

    ns_hist = defaultdict(deque)   # paciente -> fechas de inasistencias
    n_citas_prev = defaultdict(int)
    mensajes = []
    cita_id = 0
    msg_id = 0

    def siguiente_valido(dt):
        """RN-04 / CA-04: fuera de 20:00-07:00, festivos y domingos -> 07:00 del siguiente día hábil."""
        moved = False
        while True:
            d = dt.date()
            if not es_habil(d):
                dt = datetime.combine(d + timedelta(1), datetime.min.time()).replace(hour=7)
                moved = True
                continue
            if dt.hour >= 20:
                dt = datetime.combine(d + timedelta(1), datetime.min.time()).replace(hour=7)
                moved = True
                continue
            if dt.hour < 7:
                dt = dt.replace(hour=7, minute=0)
                moved = True
                continue
            return dt, moved

    def nueva_cita(f, origen, d, pac, antic_days, cita_dt, cita_origen_id=None):
        nonlocal cita_id
        cita_id += 1
        prev = ns_hist[pac]
        while prev and (d - prev[0]).days > 182:
            prev.popleft()
        ns6 = len(prev)
        primera = int(n_citas_prev[pac] == 0)
        if ns6 >= 2 or antic_days > 20:
            riesgo = 1
        elif ns6 == 1 or antic_days > 10:
            riesgo = 2
        else:
            riesgo = 3
        post = d >= policy_start
        edad_c = edad_en(pac, d)
        c = {
            "cita_id": cita_id, "origen": origen, "cita_origen_id": cita_origen_id,
            "fecha_key": int(d.strftime("%Y%m%d")), "fecha_hora_cita": cita_dt.isoformat(sep=" "),
            "franja_id": cita_dt.hour, "bloque_key": f["franja_idx"] + 1, "sede_id": f["sede_id"], "especialidad_id": f["especialidad_id"],
            "profesional_id": f["profesional_id"], "paciente_sk": pac + 1,
            "grupo_edad_id": grupo_edad(edad_c), "es_menor": int(edad_c < 18),
            "fecha_agendamiento": (cita_dt - timedelta(days=antic_days, hours=float(rng.uniform(0, 10)))).isoformat(sep=" ", timespec="minutes"),
            "anticipacion_dias": antic_days, "rango_anticipacion_id": rango_antic(antic_days),
            "inasistencias_6m_previas": ns6, "riesgo_id": riesgo, "primera_cita": primera,
            "agendamiento_restringido": int(post and ns6 >= 3),
            "periodo_politica": "POST" if post else "PRE",
            "clima_key": f"{f['sede_id']:02d}-{d.strftime('%Y%m%d')}",
            "_f": f, "_pac": pac, "_dt": cita_dt, "_d": d,
        }
        n_citas_prev[pac] += 1
        return c

    def antic_para(esp_id):
        mean = esp_info[esp_id][5] * (0.8 if esp_info[esp_id][1] == "Especialista" else 1.0)
        return int(min(75, rng.gamma(1.6, mean / 1.6)))

    def emitir_mensajes(c):
        """RN-03, RN-04, RN-11. Devuelve n entregados, respuesta."""
        nonlocal msg_id
        post = c["periodo_politica"] == "POST"
        r = c["riesgo_id"]
        if not post:
            tipos = [("UNICO_24H", 24)]
        else:
            if r == 1:
                tipos = [("72H", 72), ("24H", 24)]
            elif r == 2:
                tipos = [("24H", 24)]
            else:
                tipos = [("PRIMERA_CITA_24H", 24)] if c["primera_cita"] else []
            if c["agendamiento_restringido"]:
                tipos = [("CONFIRMACION_PREVIA", 96)] + [t for t in tipos if t[0] != "72H"]
        canal = canal_pref[c["_pac"]] if post else "SMS"  # PRE: proveedor solo SMS (contexto del caso)
        entregados, leidos, programados = 0, 0, 0
        for tipo, h in tipos:
            prog = c["_dt"] - timedelta(hours=h)
            if post:
                env, moved = siguiente_valido(prog)
            else:
                env, moved = prog, False
            programados += 1
            msg_id += 1
            row = {"mensaje_id": msg_id, "idempotency_key": f"{c['cita_id']}-{tipo}", "cita_id": c["cita_id"],
                   "tipo_recordatorio": tipo, "canal": canal,
                   "destinatario": "ACUDIENTE" if c["es_menor"] else "PACIENTE",
                   "riesgo_id": r, "sede_id": c["sede_id"], "especialidad_id": c["especialidad_id"],
                   "periodo_politica": c["periodo_politica"],
                   "fecha_hora_programada": prog.isoformat(sep=" ", timespec="minutes"),
                   "fecha_hora_envio": None, "fecha_envio_key": None,
                   "reprogramado_rn04": int(moved), "estado_final": None, "respuesta": None, "costo_cop": 0.0}
            if env >= c["_dt"] - timedelta(hours=1):
                row["estado_final"] = "OMITIDO_VENTANA"
            else:
                row["fecha_hora_envio"] = env.isoformat(sep=" ", timespec="minutes")
                row["fecha_envio_key"] = int(env.strftime("%Y%m%d"))
                row["costo_cop"] = A["costo_whatsapp_cop"] if canal == "WhatsApp" else A["costo_sms_cop"]
                if rng.random() < A["p_entrega"]:
                    entregados += 1
                    if rng.random() < A["p_leido_si_entregado"]:
                        leidos += 1
                        row["estado_final"] = "LEIDO"
                    else:
                        row["estado_final"] = "ENTREGADO"
                else:
                    row["estado_final"] = "FALLIDO"
            mensajes.append(row)
        c["recordatorios_programados"] = programados
        c["recordatorios_entregados"] = entregados
        c["_leidos"] = leidos
        return entregados, leidos

    def resolver(c):
        """Resultado de la cita según RN-01 (inasistencia) y RN-07."""
        f, d = c["_f"], c["_d"]
        x = args.base_logit + esp_info[c["especialidad_id"]][6] + 0.032 * (min(c["anticipacion_dias"], 45) - 7) \
            + propension[c["_pac"]] + AJ_EDAD[c["grupo_edad_id"]] + AJ_DOW[d.weekday()] \
            + (0.15 if c["franja_id"] == 7 else 0.10 if c["franja_id"] >= 15 else 0) \
            + 0.013 * precip[(c["sede_id"], c["fecha_key"])] + 0.22 * min(c["inasistencias_6m_previas"], 4)
        if c["origen"] == "LISTA_ESPERA":
            x -= 1.3
        if c["origen"] == "SOBRECUPO":
            x -= 0.4
        entregados, leidos = emitir_mensajes(c)
        odds = math.exp(x)
        if entregados == 1:
            odds *= A["or_1_recordatorio"]
        elif entregados >= 2:
            odds *= A["or_2_recordatorios"]
        respuesta = "SIN_RESPUESTA"
        # RN-07: agendamiento restringido -> confirmación previa obligatoria
        if c["agendamiento_restringido"]:
            if entregados and rng.random() < A["p_confirma_restringido"]:
                respuesta = "CONFIRMO"
                odds *= A["or_confirmado_restringido"]
            else:
                c.update(respuesta="SIN_CONFIRMACION", estado_final="CANCELADA_SISTEMA",
                         horas_cancelacion_antes=24.0, minutos_llegada=None)
                return
        p = odds / (1 + odds)
        intencion_faltar = rng.random() < p
        if intencion_faltar:
            if leidos and rng.random() < A["p_cancela_si_intencion_y_lee"]:
                c.update(respuesta="CANCELO", estado_final="CANCELADA_OPORTUNA",
                         horas_cancelacion_antes=round(float(rng.uniform(12, 70)), 1), minutos_llegada=None)
                return
            if rng.random() < A["p_cancela_telefono_si_intencion"]:
                h = round(float(rng.exponential(10)), 1)
                c.update(respuesta=respuesta, horas_cancelacion_antes=h, minutos_llegada=None,
                         estado_final="CANCELADA_OPORTUNA" if h >= 4 else "CANCELADA_TARDIA")
                return
            c.update(respuesta=respuesta, estado_final="NO_SE_PRESENTO", horas_cancelacion_antes=None,
                     minutos_llegada=None)
            return
        if leidos and respuesta == "SIN_RESPUESTA" and rng.random() < A["p_respuesta_si_leido"]:
            respuesta = "CONFIRMO"
        lleg = int(round(rng.normal(-12, 11)))
        if lleg > 20:   # RN-01: sin admisión dentro de los 20 min
            c.update(respuesta=respuesta, estado_final="LLEGADA_TARDIA", horas_cancelacion_antes=None,
                     minutos_llegada=lleg)
            return
        c.update(respuesta=respuesta, estado_final="ATENDIDA", horas_cancelacion_antes=None, minutos_llegada=lleg)

    franja_out = []
    for d in sim_days:
        if not fr_by_day.get(d):
            continue
        post = d >= policy_start
        export = d >= start
        day_citas = []
        for fi in fr_by_day[d]:
            f = franjas[fi]
            e = esp_info[f["especialidad_id"]]
            p_book = 0.82 if f["especialidad_id"] == 14 else 0.93 if e[1] == "Medicina general" else 0.98
            fc = []
            for h in f["horas"]:
                for k in range(f["cph"]):
                    if rng.random() > p_book:
                        continue
                    dt = datetime.combine(d, datetime.min.time()).replace(hour=h, minute=k * e[2])
                    c = nueva_cita(f, "REGULAR", d, fast_patient(f["especialidad_id"]), antic_para(f["especialidad_id"]), dt)
                    fc.append(c)
            # RN-05 sobre-agenda
            altos = sum(1 for c in fc if c["riesgo_id"] == 1)
            if post:
                habil = min(2, altos // 3) if e[3] else 0
            else:
                habil = int(rng.integers(1, 4)) if rng.random() < A["p_franja_sobreagenda_manual_pre"] else 0
            horas_alto = sorted(f["horas"], key=lambda hh: (-sum(1 for c in fc if c["riesgo_id"] == 1 and c["franja_id"] == hh), hh))
            usados = 0
            for k in range(habil):
                if rng.random() < 0.88:
                    usados += 1
                    hh = horas_alto[k] if post else int(rng.choice(f["horas"]))  # POST: 1 extra por hora con más riesgo Alto
                    dt = datetime.combine(d, datetime.min.time()).replace(hour=hh, minute=int(rng.integers(0, 50)))
                    fc.append(nueva_cita(f, "SOBRECUPO", d, fast_patient(f["especialidad_id"]), int(rng.integers(0, 3)), dt))
            f["altos"] = altos
            f["sobrecupos_habilitados"] = habil
            f["sobrecupos_usados"] = usados
            f["_citas"] = fc
            day_citas.extend(fc)

        # resultados + RN-06 reasignación
        for f_idx in fr_by_day[d]:
            f = franjas[f_idx]
            extra = []
            for c in f["_citas"]:
                resolver(c)
                c["cupo_reasignado"] = 0
                c["minutos_oferta_lista_espera"] = None
                if c["estado_final"] in ("CANCELADA_OPORTUNA", "CANCELADA_SISTEMA"):
                    h = c["horas_cancelacion_antes"] or 0
                    probs = A["p_reasigna_post"] if post else A["p_reasigna_pre"]
                    pr = probs["ge24"] if h >= 24 else probs["4a24"]
                    if post:
                        mins = round(float(min(rng.lognormal(1.2, 0.45), 30)), 1)
                    else:
                        mins = round(float(rng.uniform(45, 1440)), 1)
                    c["minutos_oferta_lista_espera"] = mins
                    if rng.random() < pr:
                        c["cupo_reasignado"] = 1
                        nc = nueva_cita(f, "LISTA_ESPERA", d, fast_patient(f["especialidad_id"]),
                                        max(0, int(h // 24)), c["_dt"], cita_origen_id=c["cita_id"])
                        resolver(nc)
                        nc["cupo_reasignado"] = 0
                        nc["minutos_oferta_lista_espera"] = None
                        extra.append(nc)
            f["_citas"].extend(extra)
            for c in f["_citas"]:
                if c["estado_final"] in ("NO_SE_PRESENTO", "CANCELADA_TARDIA", "LLEGADA_TARDIA"):
                    ns_hist[c["_pac"]].append(d)
            if not export:
                continue
            atendidas = sum(1 for c in f["_citas"] if c["estado_final"] == "ATENDIDA")
            agendadas = sum(1 for c in f["_citas"] if c["origen"] != "LISTA_ESPERA")
            esperando = 0
            for hh in f["horas"]:
                at_h = sum(1 for c in f["_citas"] if c["estado_final"] == "ATENDIDA" and c["franja_id"] == hh)
                esperando = max(esperando, max(0, at_h - f["cph"]) + int(rng.poisson(0.35 + 0.35 * at_h / f["cph"])))
            franja_out.append({
                "bloque_key": f["franja_idx"] + 1, "fecha_key": int(d.strftime("%Y%m%d")), "bloque": f["bloque"],
                "hora_inicio": f["horas"][0], "horas_bloque": len(f["horas"]),
                "sede_id": f["sede_id"], "especialidad_id": f["especialidad_id"], "profesional_id": f["profesional_id"],
                "cupos_regulares": f["cupos_regulares"], "sobrecupos_habilitados": f["sobrecupos_habilitados"],
                "sobrecupos_usados": f["sobrecupos_usados"],
                "cupos_ofertados": f["cupos_regulares"] + f["sobrecupos_habilitados"],
                "citas_agendadas": agendadas, "citas_riesgo_alto": f["altos"], "citas_atendidas": atendidas,
                "max_pacientes_esperando": esperando,
                "sala_colapsada": int(esperando > A["umbral_sala_colapsada"]),
                "periodo_politica": "POST" if post else "PRE",
            })
            citas.extend(f["_citas"])

    # ---------------- fact_citas ----------------
    fc = pd.DataFrame(citas)
    fc["es_inasistencia"] = fc["estado_final"].isin(["NO_SE_PRESENTO", "CANCELADA_TARDIA", "LLEGADA_TARDIA"]).astype(int)
    fc["es_atendida"] = (fc["estado_final"] == "ATENDIDA").astype(int)
    fc["es_cancelada_oportuna"] = fc["estado_final"].isin(["CANCELADA_OPORTUNA", "CANCELADA_SISTEMA"]).astype(int)
    fc["debia_asistir"] = 1 - fc["es_cancelada_oportuna"]
    fc["con_recordatorio_entregado"] = (fc["recordatorios_entregados"] > 0).astype(int)
    fc["oferta_lista_espera_menor_10min"] = np.where(fc["minutos_oferta_lista_espera"].notna(),
                                                     (fc["minutos_oferta_lista_espera"] < 10).astype(int), np.nan)
    precond = fc[["_pac", "_d", "grupo_edad_id", "periodo_politica", "debia_asistir", "es_inasistencia"]].copy()
    fc = fc.drop(columns=[c for c in fc.columns if c.startswith("_")])
    for col in ("cita_origen_id",):
        fc[col] = fc[col].astype("Int64")

    # ---------------- agregado de condiciones crónicas (RN-09, k-anonimato) ----------------
    rows = []
    precond["anio_mes"] = precond["_d"].map(lambda x: f"{x.year}-{x.month:02d}")
    for cname, _ in CONDICIONES:
        mask = cond[cname][precond["_pac"].values]
        g = precond[mask].groupby(["anio_mes", "grupo_edad_id", "periodo_politica"]).agg(
            citas_debia_asistir=("debia_asistir", "sum"), inasistencias=("es_inasistencia", "sum"),
            pacientes_distintos=("_pac", "nunique")).reset_index()
        g["condicion_cronica"] = cname
        rows.append(g)
    agg = pd.concat(rows)
    sup = agg["pacientes_distintos"] < A["k_anonimato"]
    agg["suprimido_k_anonimato"] = sup.astype(int)
    agg.loc[sup, ["citas_debia_asistir", "inasistencias"]] = np.nan
    agg = agg.drop(columns=["pacientes_distintos"])

    # ---------------- calidad de datos (silver -> métricas observabilidad) ----------------
    cal = []
    for d in days:
        fk = int(d.strftime("%Y%m%d"))
        n_day = 1 if es_habil(d) else 0
        if not n_day:
            continue
        base = len(fr_by_day[d]) * 2
        for fuente, tipo, rate, accion in [
            ("F2 Agendamiento", "Paciente duplicado (nombre/documento)", 0.004, "Unificado (MDM)"),
            ("F2 Agendamiento", "Fecha agendamiento > fecha cita", 0.002, "Cuarentena"),
            ("F3 Admisiones", "Admisión de cita inexistente", 0.003, "Cuarentena"),
            ("F3 Admisiones", "Codificación Latin-1 / separador ';'", 0.05, "Corregido"),
            ("F4 Mensajería", "Webhook duplicado", 0.03, "Descartado (idempotencia)"),
            ("F4 Mensajería", "Estado que retrocede (leído->enviado)", 0.01, "Descartado (máquina de estados)"),
        ]:
            cal.append({"fecha_key": fk, "fuente": fuente, "tipo_defecto": tipo,
                        "registros": int(rng.poisson(base * rate)), "accion": accion})
    for s in range(1, len(SEDES) + 1):  # archivos tardíos F3
        for d in days:
            if es_habil(d) and rng.random() < 0.02:
                cal.append({"fecha_key": int(d.strftime("%Y%m%d")), "fuente": "F3 Admisiones",
                            "tipo_defecto": f"Archivo tardío sede {s:02d}", "registros": 1,
                            "accion": "Reproceso RN-01 (ventana 3 días)"})
    calidad = pd.DataFrame(cal)

    fm = pd.DataFrame(mensajes)
    fm = fm[fm["cita_id"].isin(fc["cita_id"])].reset_index(drop=True)
    # respuesta por mensaje: la última leída de la cita recibe la respuesta
    resp = fc.set_index("cita_id")["respuesta"]
    fm["respuesta"] = fm["cita_id"].map(resp)
    last_read = fm[fm["estado_final"] == "LEIDO"].groupby("cita_id")["mensaje_id"].max()
    fm.loc[~fm["mensaje_id"].isin(last_read.values) | fm["respuesta"].isin(["SIN_RESPUESTA", "SIN_CONFIRMACION"]), "respuesta"] = None
    fm.loc[fm["respuesta"].notna(), "estado_final"] = "RESPONDIDO"
    fm["fecha_envio_key"] = fm["fecha_envio_key"].astype("Int64")
    fm.insert(3, "fecha_cita_key", fm["cita_id"].map(fc.set_index("cita_id")["fecha_key"]))

    fr = pd.DataFrame(franja_out)

    # ---------------- escritura ----------------
    def w(df, name):
        df.to_csv(out / f"{name}.csv", index=False, encoding="utf-8")
        print(f"{name:28s} {len(df):>10,} filas")

    w(dim_fecha, "dim_fecha"); w(dim_sede, "dim_sede"); w(dim_esp, "dim_especialidad")
    w(dim_prof, "dim_profesional"); w(dim_pac, "dim_paciente"); w(dim_franja, "dim_franja")
    w(dim_riesgo, "dim_riesgo"); w(dim_grupo_edad, "dim_grupo_edad"); w(dim_rango, "dim_rango_anticipacion")
    w(dim_clima, "dim_clima"); w(fc, "fact_citas"); w(fm, "fact_mensajes"); w(fr, "fact_agenda_bloque")
    w(agg, "agg_condicion_cronica"); w(calidad, "fact_calidad_datos")

    # ---------------- totales de control (CT-10) calculados fuera de Power BI ----------------
    ctrl = []
    for per in ("PRE", "POST", "TOTAL"):
        x = fc if per == "TOTAL" else fc[fc.periodo_politica == per]
        y = fr if per == "TOTAL" else fr[fr.periodo_politica == per]
        z = fm if per == "TOTAL" else fm[fm.periodo_politica == per]
        ctrl += [
            {"periodo": per, "indicador": "Citas programadas", "valor": int(len(x))},
            {"periodo": per, "indicador": "Inasistencias", "valor": int(x.es_inasistencia.sum())},
            {"periodo": per, "indicador": "Tasa inasistencia", "valor": round(x.es_inasistencia.sum() / x.debia_asistir.sum(), 6)},
            {"periodo": per, "indicador": "Ocupación efectiva", "valor": round(y.citas_atendidas.sum() / y.cupos_ofertados.sum(), 6)},
            {"periodo": per, "indicador": "Costo mensajes COP", "valor": float(z.costo_cop.sum())},
        ]
    w(pd.DataFrame(ctrl), "control_totales")


if __name__ == "__main__":
    main()
