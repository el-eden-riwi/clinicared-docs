"""
Construye el proyecto Power BI (.pbip) de ClínicaRed:
  ClinicaRed.pbip
  ClinicaRed.SemanticModel/   (TMDL: tablas, tipos, relaciones, orden, medidas)
  ClinicaRed.Report/          (PBIR: 7 páginas con visuales)
Uso: python build_pbip.py <carpeta_kit> <carpeta_salida> <tema_base.json>
"""
import json
import re
import shutil
import sys
import uuid
from pathlib import Path

KIT = Path(sys.argv[1])
OUT = Path(sys.argv[2])
BASE_THEME = Path(sys.argv[3])
NAME = "ClinicaRed"
NS = uuid.UUID("6f1c2b3a-1111-4c4c-9a9a-000000000001")


def guid(*parts):
    return str(uuid.uuid5(NS, "|".join(parts)))


T = "\t"

# ---------------------------------------------------------------- esquemas desde el M
m_text = (KIT / "powerbi/01_power_query.m").read_text(encoding="utf-8")
fn_start = m_text.index("(nombre as text) as table =>")
fn_end = m_text.index("// ---------- Consultas")
fn_body = m_text[fn_start:fn_end].rstrip()
schemas = {}
for line in fn_body.splitlines():
    mm = re.match(r"\s+(\w+) = \{(.*)\},?$", line)
    if mm:
        cols = re.findall(r'\{"(\w+)", ([\w. ]+?)\}', mm.group(2))
        schemas[mm.group(1)] = cols
TYPE = {"Int64.Type": "int64", "type number": "double", "type text": "string",
        "type date": "dateTime", "type datetime": "dateTime"}

# ---------------------------------------------------------------- medidas desde el DAX
dax = (KIT / "powerbi/02_medidas.dax").read_text(encoding="utf-8")
dax = dax[dax.index("DEFINE") + len("DEFINE"): dax.index("EVALUATE")]
blocks = re.split(r"\n    MEASURE ", "\n" + dax)
measures = {}  # tabla -> [(nombre, expr)]
for b in blocks[1:]:
    head, _, rest = b.partition(" =")
    tbl, name = re.match(r"(\w+)\[(.+)\]", head.strip()).groups()
    lines = [l for l in rest.splitlines()]
    # quitar comentarios y vacías al final
    while lines and (not lines[-1].strip() or lines[-1].strip().startswith("//")):
        lines.pop()
    expr_lines = [l[8:] if l.startswith(" " * 8) else l.strip() for l in lines]
    if expr_lines and expr_lines[0].strip() == "":
        expr_lines = expr_lines[1:]
    measures.setdefault(tbl, []).append((name, "\n".join(x.rstrip() for x in expr_lines).strip()))


def fmt(name):
    n = name.lower()
    if name == "Cuadre CT-10" or name.startswith(("Color ", "Estado ")):
        return None
    if "costo unitario" in n or "costo por" in n:
        return "$ #,0.0"
    if n.startswith("costo") or n.startswith("control costo"):
        return "$ #,0"
    if any(k in n for k in ("tasa", "ocupación", "%", "variación", "meta", "brecha", "efecto")):
        return "0.0%"
    if "mensajes por cita" in n:
        return "0.00"
    if "promedio" in n:
        return "#,0.0"
    return "#,0"


def q(name):
    return name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) else "'" + name.replace("'", "''") + "'"


HIDDEN_SUFFIX = ("_id", "_key", "_sk", "_hash")
SORT_BY = {("dim_fecha", "mes"): "mes_num", ("dim_fecha", "dia_semana"): "dia_semana_num",
           ("dim_riesgo", "nivel_riesgo"): "orden", ("dim_grupo_edad", "grupo_edad"): "orden",
           ("dim_rango_anticipacion", "rango_anticipacion"): "orden",
           ("dim_clima", "categoria_lluvia"): "categoria_lluvia_orden",
           ("dim_fecha", "anio_mes"): "mes_anio_orden"}
KEEP_VISIBLE = {("fact_citas", "cita_id")}

# ---------------------------------------------------------------- semantic model
sm = OUT / f"{NAME}.SemanticModel"
defn = sm / "definition"
(defn / "tables").mkdir(parents=True, exist_ok=True)
(sm / "definition.pbism").write_text(json.dumps({
    "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
    "version": "4.0", "settings": {}}, indent=2), encoding="utf-8")
(defn / "database.tmdl").write_text("database\n\tcompatibilityLevel: 1567\n\n", encoding="utf-8")

tables = list(schemas)
model = ["model Model", f"{T}culture: es-CO", f"{T}defaultPowerBIDataSourceVersion: powerBI_V3",
         f"{T}discourageImplicitMeasures", f"{T}sourceQueryCulture: es-CO",
         f"{T}dataAccessOptions", f"{T}{T}legacyRedirects", f"{T}{T}returnErrorValuesAsNull", "",
         "annotation __PBI_TimeIntelligenceEnabled = 0", "",
         'annotation PBI_QueryOrder = ' + json.dumps(["RutaDatos", "fnCargarCsv"] + tables), ""]
model += [f"ref table {t}" for t in tables] + [""]
(defn / "model.tmdl").write_text("\n".join(model) + "\n", encoding="utf-8")

fn_lines = fn_body.splitlines()
expr = [
    'expression RutaDatos = "C:\\ClinicaRed\\data" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]',
    f"{T}lineageTag: {guid('expr', 'RutaDatos')}", "",
    f"{T}annotation PBI_ResultType = Text", "",
    "expression fnCargarCsv =",
] + [f"{T}{T}{l}" if l.strip() else "" for l in fn_lines] + [
    f"{T}lineageTag: {guid('expr', 'fnCargarCsv')}", "",
    f"{T}annotation PBI_ResultType = Function", "",
]
(defn / "expressions.tmdl").write_text("\n".join(expr) + "\n", encoding="utf-8")

for t in tables:
    L = [f"table {t}", f"{T}lineageTag: {guid('t', t)}", ""]
    for name, ex in measures.get(t, []):
        ex_lines = ex.splitlines()
        if len(ex_lines) == 1:
            L.append(f"{T}measure {q(name)} = {ex_lines[0]}")
        else:
            L.append(f"{T}measure {q(name)} =")
            L += [f"{T}{T}{T}{l}" if l.strip() else "" for l in ex_lines]
        f = fmt(name)
        if f:
            L.append(f"{T}{T}formatString: {f}")
        L.append(f"{T}{T}lineageTag: {guid('m', t, name)}")
        L.append("")
    for col, ty in schemas[t]:
        dt = TYPE[ty]
        L.append(f"{T}column {q(col)}")
        L.append(f"{T}{T}dataType: {dt}")
        if (col.endswith(HIDDEN_SUFFIX) or col in ("orden", "mes_num", "dia_semana_num", "mes_anio_orden",
                                                    "categoria_lluvia_orden")) and (t, col) not in KEEP_VISIBLE:
            L.append(f"{T}{T}isHidden")
        if ty == "type date":
            L.append(f"{T}{T}formatString: Short Date")
        elif ty == "type datetime":
            L.append(f"{T}{T}formatString: General Date")
        elif dt == "int64":
            L.append(f"{T}{T}formatString: 0")
        L.append(f"{T}{T}lineageTag: {guid('c', t, col)}")
        L.append(f"{T}{T}summarizeBy: none")
        L.append(f"{T}{T}sourceColumn: {col}")
        if (t, col) in SORT_BY:
            L.append(f"{T}{T}sortByColumn: {SORT_BY[(t, col)]}")
        L.append("")
        L.append(f"{T}{T}annotation SummarizationSetBy = Automatic")
        L.append("")
    L += [f"{T}partition {t} = m", f"{T}{T}mode: import", f"{T}{T}source =",
          f"{T}{T}{T}{T}let", f"{T}{T}{T}{T}    Origen = fnCargarCsv(\"{t}\")", f"{T}{T}{T}{T}in",
          f"{T}{T}{T}{T}    Origen", "", f"{T}annotation PBI_ResultType = Table", ""]
    (defn / "tables" / f"{t}.tmdl").write_text("\n".join(L) + "\n", encoding="utf-8")

RELS = [("fact_citas", c, d, k) for c, d, k in [
    ("fecha_key", "dim_fecha", "fecha_key"), ("sede_id", "dim_sede", "sede_id"),
    ("especialidad_id", "dim_especialidad", "especialidad_id"), ("profesional_id", "dim_profesional", "profesional_id"),
    ("paciente_sk", "dim_paciente", "paciente_sk"), ("franja_id", "dim_franja", "franja_id"),
    ("riesgo_id", "dim_riesgo", "riesgo_id"), ("grupo_edad_id", "dim_grupo_edad", "grupo_edad_id"),
    ("rango_anticipacion_id", "dim_rango_anticipacion", "rango_anticipacion_id"), ("clima_key", "dim_clima", "clima_key")]]
RELS += [("fact_agenda_bloque", c, d, c) for c, d in [("fecha_key", "dim_fecha"), ("sede_id", "dim_sede"),
                                                      ("especialidad_id", "dim_especialidad"), ("profesional_id", "dim_profesional")]]
RELS += [("fact_mensajes", "fecha_cita_key", "dim_fecha", "fecha_key")]
RELS += [("fact_mensajes", c, d, c) for c, d in [("sede_id", "dim_sede"), ("especialidad_id", "dim_especialidad"), ("riesgo_id", "dim_riesgo")]]
RELS += [("fact_calidad_datos", "fecha_key", "dim_fecha", "fecha_key"),
         ("agg_condicion_cronica", "grupo_edad_id", "dim_grupo_edad", "grupo_edad_id")]
R = []
for ft, fc, dt_, dc in RELS:
    assert fc in dict(schemas[ft]) and dc in dict(schemas[dt_]), (ft, fc, dt_, dc)
    R += [f"relationship {guid('r', ft, fc, dt_)}", f"{T}fromColumn: {ft}.{fc}", f"{T}toColumn: {dt_}.{dc}", ""]
(defn / "relationships.tmdl").write_text("\n".join(R) + "\n", encoding="utf-8")

# ---------------------------------------------------------------- report (PBIR) con diseño
rp = OUT / f"{NAME}.Report"
rdef = rp / "definition"
(rdef / "pages").mkdir(parents=True, exist_ok=True)
(rp / "StaticResources/SharedResources/BaseThemes").mkdir(parents=True, exist_ok=True)
(rp / "StaticResources/RegisteredResources").mkdir(parents=True, exist_ok=True)
shutil.copy(BASE_THEME, rp / "StaticResources/SharedResources/BaseThemes/CY24SU10.json")
shutil.copy(KIT / "powerbi/03_tema_clinicared.json", rp / "StaticResources/RegisteredResources/ClinicaRed_tema.json")

SCH = "https://developer.microsoft.com/json-schemas/fabric/item/report/"
(rp / "definition.pbir").write_text(json.dumps({
    "$schema": SCH + "definitionProperties/2.0.0/schema.json", "version": "4.0",
    "datasetReference": {"byPath": {"path": f"../{NAME}.SemanticModel"}}}, indent=2), encoding="utf-8")
(rdef / "version.json").write_text(json.dumps({"$schema": SCH + "definition/versionMetadata/1.0.0/schema.json",
                                               "version": "2.0.0"}, indent=2), encoding="utf-8")
(rdef / "report.json").write_text(json.dumps({
    "$schema": SCH + "definition/report/1.3.0/schema.json",
    "layoutOptimization": "None",
    "themeCollection": {
        "baseTheme": {"name": "CY24SU10", "reportVersionAtImport": "5.61", "type": "SharedResources"},
        "customTheme": {"name": "ClinicaRed_tema.json", "reportVersionAtImport": "5.61", "type": "RegisteredResources"}},
    "resourcePackages": [
        {"name": "SharedResources", "type": "SharedResources",
         "items": [{"name": "CY24SU10", "path": "BaseThemes/CY24SU10.json", "type": "BaseTheme"}]},
        {"name": "RegisteredResources", "type": "RegisteredResources",
         "items": [{"name": "ClinicaRed_tema.json", "path": "ClinicaRed_tema.json", "type": "CustomTheme"}]}],
    "settings": {"useStylableVisualContainerHeader": True, "defaultDrillFilterOtherVisuals": True,
                 "allowChangeFilterTypes": True, "useEnhancedTooltips": True}}, indent=2), encoding="utf-8")

ALL_MEASURES = {n: t for t, ms in measures.items() for n, _ in ms}
NAVY, TEAL, BG, LINE, INK, MUTED = "#0B3C5D", "#0F6E8C", "#EEF2F6", "#DCE3EA", "#1F2A33", "#5B6B79"


def lit(v):
    return {"expr": {"Literal": {"Value": v}}}


def col(hexc):
    return {"solid": {"color": lit(f"'{hexc}'")}}


def mcolor(ref):
    t, m = ref.split(".", 1)
    assert ALL_MEASURES.get(m) == t, ref
    return {"solid": {"color": {"expr": {"Measure": {"Expression": {"SourceRef": {"Entity": t}}, "Property": m}}}}}


def field(ref):
    t, c = ref.split(".", 1)
    if ALL_MEASURES.get(c) == t:
        return {"Measure": {"Expression": {"SourceRef": {"Entity": t}}, "Property": c}}
    assert c in dict(schemas[t]), ref
    return {"Column": {"Expression": {"SourceRef": {"Entity": t}}, "Property": c}}


def proj(ref):
    p = {"field": field(ref), "queryRef": ref}
    if "Column" in p["field"]:
        p["active"] = True
    return p


def container(title=None, bg="#FFFFFF", border=True, shadow=True):
    o = {"background": [{"properties": {"show": lit("true"), "color": col(bg), "transparency": lit("0D")}}],
         "border": [{"properties": {"show": lit("true" if border else "false"), "color": col(LINE), "radius": lit("10D")}}],
         "dropShadow": [{"properties": {"show": lit("true" if shadow else "false"), "preset": lit("'BottomRight'"),
                                        "transparency": lit("88D")}}],
         "padding": [{"properties": {"top": lit("6D"), "bottom": lit("6D"), "left": lit("8D"), "right": lit("8D")}}]}
    if title:
        o["title"] = [{"properties": {"show": lit("true"), "text": lit("'" + title.replace("'", "''") + "'"),
                                      "fontColor": col(INK), "fontSize": lit("11D"), "bold": lit("true")}}]
    else:
        o["title"] = [{"properties": {"show": lit("false")}}]
    return o


z = [0]


def visual(page, vid, vtype, x, y, w, h, roles=None, title=None, sort=None, objects=None, cont=None):
    z[0] += 1000
    v = {"visualType": vtype}
    if roles:
        v["query"] = {"queryState": {r: {"projections": [proj(f) for f in fs]} for r, fs in roles.items()}}
        if sort:
            v["query"]["sortDefinition"] = {"sort": [{"field": field(sort[0]), "direction": sort[1]}]}
    if objects:
        v["objects"] = objects
    v["visualContainerObjects"] = cont if cont is not None else container(title)
    v["drillFilterOtherVisuals"] = True
    d = {"$schema": SCH + "definition/visualContainer/2.0.0/schema.json", "name": vid,
         "position": {"x": x, "y": y, "z": z[0], "width": w, "height": h, "tabOrder": z[0]}, "visual": v}
    p = rdef / "pages" / page / "visuals" / vid
    p.mkdir(parents=True, exist_ok=True)
    (p / "visual.json").write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")


LABELS = {"labels": [{"properties": {"show": lit("true"), "fontSize": lit("9D")}}]}


def chart(page, vid, vtype, x, y, w, h, roles, title, sort=None, labels=True):
    visual(page, vid, vtype, x, y, w, h, roles=roles, title=title, sort=sort, objects=LABELS if labels else None)


def card(page, vid, measure, x, y, w, h, title, color_measure=None, size="24D"):
    lab = {"fontSize": lit(size), "labelDisplayUnits": lit("1D")}
    lab["color"] = mcolor(color_measure) if color_measure else col(TEAL)
    visual(page, vid, "card", x, y, w, h, roles={"Values": [measure]}, title=title,
           objects={"labels": [{"properties": lab}], "categoryLabels": [{"properties": {"show": lit("false")}}]})


pages = []


def page(pid, name, subtitle):
    z[0] = 0
    pages.append(pid)
    p = rdef / "pages" / pid
    p.mkdir(parents=True, exist_ok=True)
    (p / "page.json").write_text(json.dumps({
        "$schema": SCH + "definition/page/1.4.0/schema.json", "name": pid, "displayName": name,
        "displayOption": "FitToPage", "height": 720, "width": 1280,
        "objects": {"background": [{"properties": {"color": col(BG), "transparency": lit("0D")}}],
                    "outspace": [{"properties": {"color": col(BG), "transparency": lit("0D")}}]}},
        indent=2, ensure_ascii=False), encoding="utf-8")
    # banda de encabezado
    visual(pid, "encabezado", "textbox", 0, 0, 1280, 66, cont=container(bg=NAVY, border=False, shadow=False),
           objects={"general": [{"properties": {"paragraphs": [
               {"textRuns": [{"value": "ClínicaRed  ·  ", "textStyle": {"fontSize": "20pt", "color": "#8FD3E8", "fontWeight": "bold"}},
                             {"value": name, "textStyle": {"fontSize": "20pt", "color": "#FFFFFF", "fontWeight": "bold"}}]},
               {"textRuns": [{"value": subtitle, "textStyle": {"fontSize": "10pt", "color": "#C9DCE8"}}]}]}}]})
    for vid, ref, x, t in (("slc_mes", "dim_fecha.anio_mes", 870, "Mes"), ("slc_sede", "dim_sede.sede", 1072, "Sede")):
        visual(pid, vid, "slicer", x, 9, 192, 48, roles={"Values": [ref]}, title=t,
               objects={"data": [{"properties": {"mode": lit("'Dropdown'")}}]},
               cont=container(t, border=False, shadow=False))
    visual(pid, "navegacion", "pageNavigator", 16, 74, 1248, 34, cont=container(bg=BG, border=False, shadow=False))


C, A, M = "fact_citas.", "fact_agenda_bloque.", "fact_mensajes."
Y0, G = 118, 12

# P1 Resumen
page("p1_resumen", "Resumen ejecutivo", "Metas: inasistencia < 15 %  ·  costo de recordatorios -30 %  ·  ocupación de especialistas 90 %")
w6 = (1248 - 5 * G) // 6
k = [(C + "Tasa inasistencia", "Inasistencia · meta < 15 %", C + "Color KPI inasistencia"),
     (M + "Variación costo mensual POST vs PRE", "Costo mensajes · meta -30 %", M + "Color KPI costo"),
     (A + "Ocupación especialistas", "Ocupación especialistas · meta 90 %", A + "Color KPI ocupación"),
     (C + "% ofertas a lista de espera < 10 min", "Lista de espera < 10 min", C + "Color KPI lista de espera"),
     ("control_totales.Cuadre CT-10", "Control CT-10", "control_totales.Color KPI control"),
     (C + "Estado de carga", "Estado de los datos", None)]
for i, (mref, t, cm) in enumerate(k):
    card("p1_resumen", f"k{i}", mref, 16 + i * (w6 + G), Y0, w6, 112, t, cm,
         size="22D" if i < 4 else "11D")
chart("p1_resumen", "l_tend", "lineChart", 16, 242, 760, 462,
      {"Category": ["dim_fecha.anio_mes"], "Y": [C + "Tasa inasistencia", C + "Meta inasistencia"]},
      "Inasistencia mensual vs meta (la política inicia en 2026-05)", ("dim_fecha.anio_mes", "Ascending"))
chart("p1_resumen", "c_riesgo", "clusteredColumnChart", 788, 242, 476, 462,
      {"Category": ["dim_riesgo.nivel_riesgo"], "Series": ["dim_fecha.periodo_politica"], "Y": [C + "Tasa inasistencia"]},
      "Inasistencia por nivel de riesgo: antes (PRE) vs después (POST)", ("dim_riesgo.nivel_riesgo", "Ascending"))

# P2 Inasistencia
page("p2_inasistencia", "Inasistencia", "Pregunta 1: ¿dónde y cuándo faltan los pacientes? Sede, especialidad, franja, día y edad")
chart("p2_inasistencia", "b_sede", "clusteredBarChart", 16, Y0, 400, 586,
      {"Category": ["dim_sede.sede"], "Y": [C + "Tasa inasistencia"]}, "Por sede", (C + "Tasa inasistencia", "Descending"))
chart("p2_inasistencia", "b_esp", "clusteredBarChart", 428, Y0, 410, 378,
      {"Category": ["dim_especialidad.especialidad"], "Y": [C + "Tasa inasistencia"]}, "Por especialidad",
      (C + "Tasa inasistencia", "Descending"))
visual("p2_inasistencia", "m_calor", "pivotTable", 850, Y0, 414, 378,
       roles={"Rows": ["dim_fecha.dia_semana"], "Columns": ["dim_franja.franja"], "Values": [C + "Tasa inasistencia"]},
       title="Mapa de calor: día × franja horaria",
       objects={"values": [{"properties": {"backColor": mcolor(C + "Color calor inasistencia")},
                            "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}],
                                         "metadata": "fact_citas.Tasa inasistencia"}}]})
chart("p2_inasistencia", "c_edad", "clusteredColumnChart", 428, 508, 410, 196,
      {"Category": ["dim_grupo_edad.grupo_edad"], "Y": [C + "Tasa inasistencia"]}, "Por grupo de edad",
      ("dim_grupo_edad.grupo_edad", "Ascending"))
visual("p2_inasistencia", "t_estado", "tableEx", 850, 508, 414, 196,
       roles={"Values": [C + "estado_final", C + "Citas programadas"]}, title="Estado final de las citas")

# P3 Ocupación
page("p3_ocupacion", "Ocupación efectiva", "Pregunta 2: citas atendidas / cupos ofertados (RN-08) por profesional, sede y especialidad")
visual("p3_ocupacion", "g_ocup", "gauge", 16, Y0, 380, 270,
       roles={"Y": [A + "Ocupación especialistas"], "TargetValue": [A + "Meta ocupación especialistas"]},
       title="Ocupación de especialistas vs meta 90 %")
chart("p3_ocupacion", "c_cat", "clusteredColumnChart", 16, 400, 380, 304,
      {"Category": ["dim_especialidad.categoria"], "Series": ["dim_fecha.periodo_politica"], "Y": [A + "Ocupación efectiva"]},
      "Por tipo de servicio: PRE vs POST")
visual("p3_ocupacion", "m_prof", "pivotTable", 408, Y0, 460, 586,
       roles={"Rows": ["dim_sede.sede", "dim_profesional.profesional"],
              "Values": [A + "Cupos ofertados", A + "Atendidas en agenda", A + "Ocupación efectiva"]},
       title="Por sede y profesional (expanda la sede)")
chart("p3_ocupacion", "l_ocup", "lineChart", 880, Y0, 384, 586,
      {"Category": ["dim_fecha.anio_mes"], "Series": ["dim_especialidad.categoria"], "Y": [A + "Ocupación efectiva"]},
      "Tendencia mensual", ("dim_fecha.anio_mes", "Ascending"), labels=False)

# P4 Recordatorios
page("p4_recordatorios", "Recordatorios y costos", "Preguntas 3 y 4: efecto de los recordatorios por riesgo, costo e inasistencias evitadas")
w4 = (1248 - 3 * G) // 4
for i, (mref, t) in enumerate([(M + "Mensajes enviados", "Mensajes enviados"), (M + "Costo mensajes", "Costo de mensajes (COP)"),
                               (C + "Inasistencias evitadas (estimado)", "Inasistencias evitadas (estimado)"),
                               (C + "Costo por inasistencia evitada", "Costo por inasistencia evitada (COP)")]):
    card("p4_recordatorios", f"k{i}", mref, 16 + i * (w4 + G), Y0, w4, 100, t)
chart("p4_recordatorios", "c_efecto", "clusteredColumnChart", 16, 230, 420, 474,
      {"Category": ["dim_riesgo.nivel_riesgo"],
       "Y": [C + "Tasa inasistencia con recordatorio", C + "Tasa inasistencia sin recordatorio"]},
      "Inasistencia con vs sin recordatorio entregado", ("dim_riesgo.nivel_riesgo", "Ascending"))
chart("p4_recordatorios", "s_costo", "columnChart", 448, 230, 440, 262,
      {"Category": ["dim_fecha.anio_mes"], "Series": [M + "canal"], "Y": [M + "Costo mensajes"]},
      "Costo mensual por canal", ("dim_fecha.anio_mes", "Ascending"), labels=False)
visual("p4_recordatorios", "t_desc", "tableEx", 448, 504, 440, 200,
       roles={"Values": ["dim_fecha.periodo_politica", M + "Mensajes por cita", M + "Costo unitario promedio",
                         M + "Costo mensual promedio", M + "Mensajes reprogramados RN-04"]},
       title="De dónde sale el ahorro: volumen vs canal")
chart("p4_recordatorios", "f_embudo", "funnel", 900, 230, 364, 474,
      {"Category": [M + "estado_final"], "Y": [M + "Mensajes enviados"]}, "Estado final de los mensajes",
      (M + "Mensajes enviados", "Descending"))

# P5 Sobre-agenda
page("p5_sobreagenda", "Sobre-agenda y sala de espera", "Pregunta 5: sobrecupos usados y bloques con sala colapsada (más de 3 pacientes esperando)")
for i, (mref, t) in enumerate([(A + "Sobrecupos usados", "Sobrecupos usados"), (A + "Bloques con sala colapsada", "Bloques con sala colapsada"),
                               (A + "% colapso con sobrecupo", "% colapso CON sobrecupo"), (A + "% colapso sin sobrecupo", "% colapso SIN sobrecupo")]):
    card("p5_sobreagenda", f"k{i}", mref, 16 + i * (w4 + G), Y0, w4, 100, t)
chart("p5_sobreagenda", "c_per", "clusteredColumnChart", 16, 230, 500, 474,
      {"Category": ["dim_fecha.periodo_politica"], "Y": [A + "Sobrecupos usados", A + "Bloques con sala colapsada"]},
      "Sobre-agenda manual (PRE) vs regla RN-05 (POST)")
chart("p5_sobreagenda", "b_esp_sob", "clusteredBarChart", 528, 230, 736, 474,
      {"Category": ["dim_especialidad.especialidad"], "Y": [A + "Sobrecupos usados", A + "Bloques con sala colapsada"]},
      "Por especialidad (en POST las no sobre-agendables quedan en 0)", (A + "Sobrecupos usados", "Descending"))

# P6 Factores
page("p6_factores", "Clima y anticipación", "Pregunta 6: ¿influyen la lluvia o los días de anticipación? + condiciones crónicas agregadas (RN-09)")
chart("p6_factores", "c_lluvia", "clusteredColumnChart", 16, Y0, 410, 586,
      {"Category": ["dim_clima.categoria_lluvia"], "Y": [C + "Tasa inasistencia"]}, "Por intensidad de lluvia del día",
      ("dim_clima.categoria_lluvia", "Ascending"))
chart("p6_factores", "c_antic", "clusteredColumnChart", 438, Y0, 410, 586,
      {"Category": ["dim_rango_anticipacion.rango_anticipacion"], "Y": [C + "Tasa inasistencia"]},
      "Por días de anticipación del agendamiento", ("dim_rango_anticipacion.rango_anticipacion", "Ascending"))
visual("p6_factores", "m_cronica", "pivotTable", 860, Y0, 404, 586,
       roles={"Rows": ["agg_condicion_cronica.condicion_cronica"], "Columns": ["dim_grupo_edad.grupo_edad"],
              "Values": ["agg_condicion_cronica.Tasa inasistencia condición crónica"]},
       title="Condición crónica × edad (agregado; celdas < 10 pacientes ocultas)")

# P7 Calidad
page("p7_calidad", "Calidad de datos", "Defectos detectados en la capa Silver por fuente y acción tomada (sección 5.3)")
chart("p7_calidad", "s_cal", "columnChart", 16, Y0, 760, 586,
      {"Category": ["dim_fecha.anio_mes"], "Series": ["fact_calidad_datos.fuente"], "Y": ["fact_calidad_datos.Registros con defecto"]},
      "Registros con defecto por mes y fuente", ("dim_fecha.anio_mes", "Ascending"), labels=False)
visual("p7_calidad", "t_cal", "tableEx", 788, Y0, 476, 586,
       roles={"Values": ["fact_calidad_datos.tipo_defecto", "fact_calidad_datos.accion", "fact_calidad_datos.Registros con defecto"]},
       title="Detalle por tipo de defecto")

(rdef / "pages" / "pages.json").write_text(json.dumps({
    "$schema": SCH + "definition/pagesMetadata/1.0.0/schema.json", "pageOrder": pages,
    "activePageName": pages[0]}, indent=2), encoding="utf-8")
(OUT / f"{NAME}.pbip").write_text(json.dumps({
    "$schema": "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
    "version": "1.0", "artifacts": [{"report": {"path": f"{NAME}.Report"}}],
    "settings": {"enableAutoRecovery": True}}, indent=2), encoding="utf-8")
(OUT / ".gitignore").write_text("**/.pbi/localSettings.json\n**/.pbi/cache.abf\n", encoding="utf-8")
print("tablas", len(tables), "medidas", sum(len(v) for v in measures.values()), "relaciones", len(RELS), "páginas", len(pages))
