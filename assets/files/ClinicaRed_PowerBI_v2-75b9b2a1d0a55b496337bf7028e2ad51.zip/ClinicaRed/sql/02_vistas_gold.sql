-- ClínicaRed — Vistas Gold de control sobre PostgreSQL (desarrollo local / consulta de control CT-10).
-- En AWS la capa Gold vive en S3 (Parquet, Spark) y Power BI la lee vía Athena; estas vistas
-- replican la misma lógica para validar que el tablero cuadra con la fuente.
-- Requiere 01_extensiones_oltp.sql. Valor de sal de seudonimización: parámetro de sesión app.pseudo_salt.

CREATE SCHEMA IF NOT EXISTS gold;

CREATE OR REPLACE VIEW gold.fact_citas AS
WITH base AS (
    SELECT
        a.id                                         AS cita_id,
        a.origin                                     AS origen,
        TO_CHAR(a.scheduled_datetime, 'YYYYMMDD')::INT AS fecha_key,
        a.scheduled_datetime                         AS fecha_hora_cita,
        EXTRACT(HOUR FROM a.scheduled_datetime)::INT AS franja_id,
        a.block_id                                   AS bloque_key,
        a.location_id                                AS sede_id,
        a.specialty_id                               AS especialidad_id,
        a.professional_id                            AS profesional_id,
        a.patient_id,
        DATE_PART('year', AGE(a.scheduled_datetime::DATE, p.date_of_birth))::INT AS edad,
        a.booked_at                                  AS fecha_agendamiento,
        GREATEST(0, (a.scheduled_datetime::DATE - a.booked_at::DATE))            AS anticipacion_dias,
        -- RN-01
        CASE
            WHEN a.cancelled_at IS NOT NULL
                 AND a.cancelled_at <= a.scheduled_datetime - INTERVAL '4 hours'   THEN 0
            WHEN att.check_in_time IS NOT NULL
                 AND att.check_in_time <= a.scheduled_datetime + INTERVAL '20 minutes' THEN 0
            WHEN a.scheduled_datetime + INTERVAL '20 minutes' > NOW()             THEN NULL  -- aún no evaluable
            ELSE 1
        END                                          AS es_inasistencia,
        CASE WHEN a.cancelled_at IS NOT NULL
                  AND a.cancelled_at <= a.scheduled_datetime - INTERVAL '4 hours' THEN 1 ELSE 0 END AS es_cancelada_oportuna,
        CASE WHEN att.check_in_time IS NOT NULL
                  AND att.check_in_time <= a.scheduled_datetime + INTERVAL '20 minutes'
                  AND a.cancelled_at IS NULL THEN 1 ELSE 0 END                    AS es_atendida
    FROM appointments a
    JOIN patients p          ON p.id = a.patient_id
    LEFT JOIN attendances att ON att.appointment_id = a.id
)
SELECT
    b.cita_id, b.origen, b.fecha_key, b.fecha_hora_cita, b.franja_id, b.bloque_key,
    b.sede_id, b.especialidad_id, b.profesional_id,
    LEFT(ENCODE(SHA256(CONVERT_TO(COALESCE(CURRENT_SETTING('app.pseudo_salt', TRUE), '') || b.patient_id::TEXT, 'UTF8')), 'hex'), 16)
                                                  AS paciente_hash,           -- RNF-01 seudonimización
    CASE WHEN b.edad < 18 THEN 1 WHEN b.edad < 30 THEN 2 WHEN b.edad < 45 THEN 3
         WHEN b.edad < 60 THEN 4 WHEN b.edad < 75 THEN 5 ELSE 6 END AS grupo_edad_id,
    (b.edad < 18)::INT                            AS es_menor,
    b.fecha_agendamiento, b.anticipacion_dias,
    h.ns6                                         AS inasistencias_6m_previas,
    -- RN-02 (en producción "no ha confirmado" sale de messages.response)
    CASE WHEN h.ns6 >= 2 OR (b.anticipacion_dias > 20 AND COALESCE(cf.confirmo, FALSE) = FALSE) THEN 1
         WHEN h.ns6 = 1 OR b.anticipacion_dias > 10 THEN 2
         ELSE 3 END                               AS riesgo_id,
    (h.ns6 >= 3)::INT                             AS agendamiento_restringido,   -- RN-07
    b.es_inasistencia, b.es_atendida, b.es_cancelada_oportuna,
    1 - b.es_cancelada_oportuna                   AS debia_asistir,
    TO_CHAR(b.sede_id, 'FM00') || '-' || b.fecha_key::TEXT AS clima_key
FROM base b
LEFT JOIN LATERAL (
    SELECT COUNT(*)::INT AS ns6
    FROM base x
    WHERE x.patient_id = b.patient_id
      AND x.es_inasistencia = 1
      AND x.fecha_hora_cita <  b.fecha_hora_cita::DATE
      AND x.fecha_hora_cita >= b.fecha_hora_cita::DATE - INTERVAL '6 months'
) h ON TRUE
LEFT JOIN LATERAL (
    SELECT BOOL_OR(m.response = 'CONFIRMO') AS confirmo
    FROM messages m WHERE m.appointment_id = b.cita_id
) cf ON TRUE;

CREATE OR REPLACE VIEW gold.fact_agenda_bloque AS
SELECT
    sb.id                                        AS bloque_key,
    TO_CHAR(sb.block_date, 'YYYYMMDD')::INT      AS fecha_key,
    CASE WHEN sb.start_hour < 12 THEN 'Mañana' ELSE 'Tarde' END AS bloque,
    sb.location_id AS sede_id, sb.specialty_id AS especialidad_id, sb.professional_id AS profesional_id,
    sb.regular_slots                             AS cupos_regulares,
    sb.extra_slots_enabled                       AS sobrecupos_habilitados,
    sb.regular_slots + sb.extra_slots_enabled    AS cupos_ofertados,
    COUNT(fc.cita_id) FILTER (WHERE fc.origen = 'SOBRECUPO')  AS sobrecupos_usados,
    COALESCE(SUM(fc.es_atendida), 0)             AS citas_atendidas            -- RN-08 numerador
FROM schedule_blocks sb
LEFT JOIN gold.fact_citas fc ON fc.bloque_key = sb.id
GROUP BY sb.id;

CREATE OR REPLACE VIEW gold.fact_mensajes AS
SELECT
    m.id AS mensaje_id, m.idempotency_key, m.appointment_id AS cita_id,
    TO_CHAR(a.scheduled_datetime, 'YYYYMMDD')::INT AS fecha_cita_key,
    m.message_type AS tipo_recordatorio, m.channel AS canal, m.recipient AS destinatario,
    a.location_id AS sede_id, a.specialty_id AS especialidad_id,
    m.scheduled_at AS fecha_hora_programada, m.sent_at AS fecha_hora_envio,
    m.rescheduled_rn04::INT AS reprogramado_rn04, m.status AS estado_final, m.response AS respuesta,
    m.cost_cop AS costo_cop
FROM messages m
JOIN appointments a ON a.id = m.appointment_id;

-- Consulta de control (CT-10): debe coincidir con la tarjeta "Cuadre CT-10" del tablero
-- SELECT COUNT(*) AS citas, SUM(es_inasistencia) AS inasistencias,
--        ROUND(SUM(es_inasistencia)::NUMERIC / NULLIF(SUM(debia_asistir), 0), 4) AS tasa
-- FROM gold.fact_citas WHERE es_inasistencia IS NOT NULL;
