-- ClínicaRed — Campos mínimos que el OLTP (01_init_schema.sql) necesita para alimentar el tablero.
-- Sin estos campos no se puede calcular RN-01 (cancelación >= 4 h), RN-05/RN-08 (cupos) ni el costo de mensajes.

ALTER TABLE specialties
    ADD COLUMN IF NOT EXISTS category      VARCHAR(40) NOT NULL DEFAULT 'Especialista',
    ADD COLUMN IF NOT EXISTS duration_min  INT         NOT NULL DEFAULT 20,
    ADD COLUMN IF NOT EXISTS overbookable  BOOLEAN     NOT NULL DEFAULT TRUE;   -- F7 "no sobre-agendable"

ALTER TABLE appointments
    ADD COLUMN IF NOT EXISTS booked_at     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP, -- fecha de agendamiento
    ADD COLUMN IF NOT EXISTS cancelled_at  TIMESTAMP,                                     -- RN-01
    ADD COLUMN IF NOT EXISTS origin        VARCHAR(20) NOT NULL DEFAULT 'REGULAR',        -- REGULAR | SOBRECUPO | LISTA_ESPERA
    ADD COLUMN IF NOT EXISTS block_id      INT;

CREATE TABLE IF NOT EXISTS schedule_blocks (               -- agenda ofertada: denominador de RN-08
    id                   SERIAL PRIMARY KEY,
    professional_id      INT  NOT NULL REFERENCES professionals(id),
    location_id          INT  NOT NULL REFERENCES locations(id),
    specialty_id         INT  NOT NULL REFERENCES specialties(id),
    block_date           DATE NOT NULL,
    start_hour           INT  NOT NULL,
    hours                INT  NOT NULL,
    regular_slots        INT  NOT NULL,
    extra_slots_enabled  INT  NOT NULL DEFAULT 0 CHECK (extra_slots_enabled BETWEEN 0 AND 2), -- RN-05
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (professional_id, block_date, start_hour)
);

ALTER TABLE messages
    ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(80),          -- RNF-03: {appointment_id}-{tipo}
    ADD COLUMN IF NOT EXISTS channel         VARCHAR(20),          -- SMS | WhatsApp
    ADD COLUMN IF NOT EXISTS recipient       VARCHAR(20) NOT NULL DEFAULT 'PACIENTE', -- RN-11: ACUDIENTE si menor
    ADD COLUMN IF NOT EXISTS scheduled_at    TIMESTAMP,
    ADD COLUMN IF NOT EXISTS rescheduled_rn04 BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS response        VARCHAR(20),          -- CONFIRMO | CANCELO
    ADD COLUMN IF NOT EXISTS cost_cop        NUMERIC(10,2) NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX IF NOT EXISTS ux_messages_idempotency ON messages (idempotency_key);
CREATE INDEX IF NOT EXISTS ix_appointments_patient_date ON appointments (patient_id, scheduled_datetime);
CREATE INDEX IF NOT EXISTS ix_appointments_updated_at ON appointments (updated_at);  -- watermark ADR-003
